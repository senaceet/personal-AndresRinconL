<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Consulta</title>
</head>
        <body>
            <hr>
            <form action="actualizacion.php" method="post">
            Ingrese el correo del alumno:
            <input type="text" name="correo">
            <br>
            <input type="submit" value="search">
            <hr>
            <br>
            <br><hr>
            </form>
                <?php
                    error_reporting(E_ALL ^ E_NOTICE);
                    $conexion= mysqli_connect("localhost","root","","baseprueba") or die("Problemas en la conexión");
                    $registros= mysqli_query($conexion,"select id,nombres,correo,identificacion,fecha from alumnos where correo='$_REQUEST[correo]'") or 
                    die("problemas en el select".mysqli_error($conexion));
                        if($reg= mysqli_fetch_array($registros)) {
                       ?>     
                        <form action="actualizacion2.php" method="post">
                        Ingrese nuevo correo:
                        <input type="text" name="correonuevo" value="<?php echo $reg['correo'] ?>">
                        <br>
                        <input type="submit" value="Modificar">
                        </form>
                        <?php
                    } else {
                        echo"No existe ningun alumno con ese correo"; 
                    }
                    echo"<br>";
                    echo"<hr>";

                    mysqli_close($conexion)
                ?>            
        </body>
</html>