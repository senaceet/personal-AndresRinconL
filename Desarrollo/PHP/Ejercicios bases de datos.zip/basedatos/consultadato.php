<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Consulta</title>
</head>
        <body>
            <hr>
            <form action="consultadato.php" method="post">
            Ingrese el correo del alumno a consultar:
            <input type="text" name="correo">
            <br>
            <input type="submit" value="search">
            <hr>
            <br>
            <br><hr>
            </form>
                <?php
                    error_reporting(E_ALL ^ E_NOTICE);
                    $conexion= mysqli_connect("localhost","root","","baseprueba") or die("Problemas en la conexión");
                    $registros= mysqli_query($conexion,"select id,nombres,correo,identificacion,fecha from alumnos where correo='$_REQUEST[correo]'") or 
                    die("problemas en el select".mysqli_error($conexion));
                        if($reg= mysqli_fetch_array($registros)) {
                        echo"nombres: ".$reg['nombres']."<br>";
                        echo"correo: ".$reg['correo']."<br>";
                    } else {
                        echo"No existe ningun alumno con ese correo"; 
                    }
                    echo"<br>";
                    echo"<hr>";

                    mysqli_close($conexion)
                ?>            
        </body>
</html>