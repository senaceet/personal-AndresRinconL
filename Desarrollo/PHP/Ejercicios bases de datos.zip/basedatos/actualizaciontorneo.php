<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Consulta</title>
</head>
        <body>
            <hr>
            <form action="actualizaciontorneo.php" method="post">
            Ingrese nombre del equipo:
            <input type="text" name="nombre">
            <br>
            <input type="submit" value="search">
            <hr>
            <br>
            <br><hr>
            </form>
                <?php
                    error_reporting(E_ALL ^ E_NOTICE);
                    $conexion= mysqli_connect("localhost","root","","torneo") or die("Problemas en la conexión");
                    $registros= mysqli_query($conexion,"select id,nombre,barrio,director,fecha from torneo where nombre='$_REQUEST[nombre]'") or 
                    die("problemas en el select".mysqli_error($conexion));
                        if($reg= mysqli_fetch_array($registros)) {
                       ?>     
                        <form action="actualizaciontorneo2.php" method="post">
                        Ingrese nuevo nombre del equipo:
                        <input type="text" name="nombrenuevo" value="<?php echo $reg['nombre'] ?>">
                        <br>
                        <input type="submit" value="Modificar">
                        </form>
                        <?php
                    } else {
                        echo"No existe ningun equipo con ese nombre"; 
                    }
                    echo"<br>";
                    echo"<hr>";

                    mysqli_close($conexion)
                ?>            
        </body>