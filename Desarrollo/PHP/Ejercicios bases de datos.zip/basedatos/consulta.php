<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Consulta</title>
</head>
        <body>
           <?php
            error_reporting(E_ALL ^ E_NOTICE);
            $conexion= mysqli_connect("localhost","root","","baseprueba") or die("Problemas en la conexión");
            $registros= mysqli_query($conexion,"select id,nombres,correo,identificacion,fecha from alumnos") or 
            die("problemas en el select".mysqli_error($conexion));
            while ($reg= mysqli_fetch_array($registros)) {
                echo"nombres: ".$reg['nombres']."<br>";
                echo"correo: ".$reg['correo']."<br>";
                echo"identificacion: ".$reg['identificacion']."<br>";
                echo"fecha: ".$reg['fecha']."<br>";
            }
             echo"<br>";
             echo"<hr>";

             mysqli_close($conexion)
            ?>            
        </body>
</html>