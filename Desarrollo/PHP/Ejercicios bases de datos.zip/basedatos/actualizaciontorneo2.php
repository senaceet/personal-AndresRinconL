<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    
    <?php
        error_reporting(E_ALL ^ E_NOTICE);
        $conexion= mysqli_connect("localhost","root","","torneo") or die("Problemas en la conexión");
        $registro= mysqli_query($conexion,"update torneo set nombre='$_REQUEST[nombrenuevo]' where nombre='$_REQUEST[nombreanterior]'") or 
        die("problemas en el select".mysqli_error($conexion));
        echo"nombre del equipo modificado exitosamentew";
    ?>
</body>
</html>