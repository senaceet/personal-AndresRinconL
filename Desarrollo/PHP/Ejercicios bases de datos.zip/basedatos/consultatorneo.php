<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Consulta</title>
</head>
        <body>
            <hr>
            <form action="consultatorneo.php" method="post">
            Ingrese el nimbre del equipo a consultar:
            <input type="text" name="nombre">
            <br>
            <input type="submit" value="search">
            <hr>
            <br>
            <br><hr>
            </form>
                <?php
                    error_reporting(E_ALL ^ E_NOTICE);
                    $conexion= mysqli_connect("localhost","root","","torneo") or die("Problemas en la conexión");
                    $registros= mysqli_query($conexion,"select id,nombre,barrio,director,fecha from torneo where nombre='$_REQUEST[nombre]'") or 
                    die("problemas en el select".mysqli_error($conexion));
                        if($reg= mysqli_fetch_array($registros)) {
                        echo"nombre: ".$reg['nombre']."<br>";
                        echo"director: ".$reg['director']."<br>";
                    } else {
                        echo"No existe ningun equipo con ese nombre"; 
                    }
                    echo"<br>";
                    echo"<hr>";

                    mysqli_close($conexion)
                ?>            
        </body>
</html>