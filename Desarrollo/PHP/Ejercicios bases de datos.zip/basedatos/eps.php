<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Prueba DataBase</title>
</head>
        <body style="background-color:#AAB7B8;"> 
                <center><form action="eps.php" method="post">
                                ID:
                                <br>
                                <input type="text" name="id">
                                <br>
                                <br>
                                Elija Localidad:
                                <br>
                                <select name="localidad">
                                    <option value="1">Usaquén</option>
                                    <option value="2">Chapinero</option>
                                    <option value="3">Santa Fe</option>
                                    <option value="4">San Cristóbal</option>
                                    <option value="5">Usme</option>
                                    <option value="6">Tunjuelito</option>
                                    <option value="7">Bosa</option>
                                    <option value="8">Kennedy</option>
                                    <option value="9">Fontibón</option>
                                    <option value="10">Engativá</option>
                                    <option value="11">Suba</option>
                                    <option value="12">Barrios Unidos</option>
                                    <option value="13">Teusaquillo</option>
                                    <option value="14">Los Mártires</option>
                                    <option value="15">Antonio Nariño</option>
                                    <option value="16">Puente Aranda</option>
                                    <option value="17">La Candelaria</option>
                                    <option value="18">Rafael Uribe Uribe</option>
                                    <option value="19">Ciudad Bolívar</option>
                                    <option value="20">Sumapaz</option>
                                </select>
                                <br>
                                <br>
                                Elija EPS:
                                <br>
                                <select name="eps">
                                    <option value="1">Salud Total S.A. E.P.S.</option>
                                    <option value="2">Cafesalud E.P.S. S.A.</option>
                                    <option value="3">E.P.S. Sanitas S.A.</option>
                                    <option value="4">Compensar E.P.S.</option>
                                    <option value="5">Colseguros E.P.S.</option>
                                    <option value="6">E.P.S. Saludcoop</option>
                                    <option value="7">Coomeva E.P.S. S.A.</option>
                                    <option value="8">E.P.S. Famisanar LTDA.</option>
                                    <option value="9">CAFAM</option>
                                    <option value="10">Colsubsidio</option>
                                </select>
                                <br>
                                <br>
                                Ingrese poblacion:
                                <br>
                                <input type="text" name="poblacion">
                                <br>
                                <br>
                                <input type="submit" value="Enviar">                
                    
                    </form></center>
                    
             <?php
             error_reporting(E_ALL ^ E_NOTICE);
             $id=$_POST['id'];
             $localidad=$_POST['localidad'];
             $eps=$_POST['eps'];
             $poblacion=$_POST['poblacion'];
             $conexion=mysqli_connect("localhost","root","","eps") or die ("problemas en la conexion");
             mysqli_query($conexion,"insert into eps(id,localidad,eps,poblacion) values('$id','$localidad','$eps','$poblacion')") or die ("problemas en el select".mysqli_error($conexion));
             mysqli_close($conexion);
             echo"Eps lista";    
             ?>

       </body>
</html>
