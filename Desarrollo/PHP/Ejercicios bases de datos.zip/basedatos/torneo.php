<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Prueba DataBase</title>
</head>
        <body style="background-color:#AAB7B8;"> 
                <center><form action="torneo.php" method="post">
                                Ingrese codigo equipo:
                                <br>
                                <input type="text" name="codigo">
                                <br>
                                <br>
                                Ingrese nombre equipo:
                                <br>
                                <input type="text" name="nombre">
                                <br>
                                <br>
                                Ingrese barrio:
                                <br>
                                <input type="text" name="barrio">
                                <br>
                                <br>
                                Ingrese nombre director del equipo:
                                <br>
                                <input type="text" name="director">
                                <br>
                                <br>
                                Ingrese fecha del partido:
                                <br>
                                <input type="text" name="fecha">
                                <br>
                                <br>
                                <input type="submit" value="Enviar">                
                    
                    </form></center>
                    
             <?php
             error_reporting(E_ALL ^ E_NOTICE);
             $id=$_POST['codigo'];
             $nombre=$_POST['nombre'];
             $barrio=$_POST['barrio'];
             $director=$_POST['director'];
             $fecha=$_POST['fecha'];
             $conexion=mysqli_connect("localhost","root","","torneo") or die ("problemas en la conexion");
             mysqli_query($conexion,"insert into torneo(id,nombre,barrio,director,fecha) values('$id','$nombre','$barrio','$director','$fecha')") or die ("problemas en el select".mysqli_error($conexion));
             mysqli_close($conexion);
             echo"equpo registrado";    
             ?>

       </body>
</html>
