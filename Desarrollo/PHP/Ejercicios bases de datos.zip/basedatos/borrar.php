<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Borrar Registro</title>
</head>
<body>
    <form action="borrar.php" method="post">
    Ingrese correo a borrar:
    <input type="text" name="correo">
    <br>
    <br>
    <input type="submit" value="Modificar">
    <hr>    
    </form>

        <?php
            error_reporting(E_ALL ^ E_NOTICE);
            $conexion= mysqli_connect("localhost","root","","baseprueba") or die("Problemas en la conexión");
            $registros= mysqli_query($conexion,"select id from alumnos where correo='$_REQUEST[correo]'") or 
            die("problemas en el select".mysqli_error($conexion));
            if ($reg=mysqli_fetch_array($registros)) {
                mysqli_query($conexion,"delete from alumnos where correo='$_REQUEST[correo]'") or die("problemas en el select".mysqli_error($conexion));
                echo"Datos borrados";
            } else{
                echo"No existe alumno con ese correo";
            }
            mysqli_close($conexion);

        ?>    
</body>
</html>