    <?php
        error_reporting(E_ALL ^ E_NOTICE);
        session_start();
    ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body><center>
    
    <?php
        echo"Nombre de usuario: ".$_SESSION['usuario']."<br>";
        echo"Contraseña: ".$_SESSION['clave'];

    ?>
    </center>
</body>
</html>