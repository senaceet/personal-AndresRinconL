<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<?php
        if ($_POST['radio']=="rojo") {
            setcookie("color","#FF0000",time()+60*60*24*365,"/");
        }elseif ($_POST['radio']=="azul") {
            setcookie("color","#0000FF",time()+60*60*24*365,"/");
        }elseif ($_POST['radio']=="amarillo") {
            setcookie("color","#FFFF00",time()+60*60*24*365,"/");
        }elseif ($_POST['radio']=="verde") {
            setcookie("color","#008000",time()+60*60*24*365,"/");
        }elseif ($_POST['radio']=="fucsia") {
            setcookie("color","#FF00FF",time()+60*60*24*365,"/");
        }elseif ($_POST['radio']=="gris") {
            setcookie("color","#808080",time()+60*60*24*365,"/");
        }
    ?>
    <a href="galletas.php">Volver a la pagina anterior para elegir otro color</a>
</body>
</html>