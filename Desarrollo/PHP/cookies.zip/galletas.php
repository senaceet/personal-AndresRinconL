<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body
    <?php
    //error_reporting(E_ALL ^ E_NOTICE);
if(isset($_COOKIE['color']))
echo "style=\"background:$_COOKIE[color]\"";
     if (isset($_COOKIE['color'])) echo"style=\"background:$_COOKIE[color]\"";
    ?> >
    <form action="galletas2.php" method="POST">
        Seleccione de que color desea ver la pagina: <br>
            <input type="radio" value="rojo" name="radio" >Rojo <br>
            <input type="radio" name="radio" value="azul">Azul <br>
            <input type="radio" name="radio" value="amarillo">Amarillo <br>
            <input type="radio" name="radio" value="verde">Verde <br>
            <input type="radio" name="radio" value="fucsia">Fucsia <br>
            <input type="radio" name="radio" value="gris">Gris <br>
            <input type="submit" value="Crear cookie">    
    </form>


</body>
</html>