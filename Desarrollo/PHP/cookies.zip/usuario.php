<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sesion1</title>
</head>
<body>
    <center><form action="usuario.php" method="POST">
        Ingrese nombre del usuario a registrar: <br>
        <input type="text" name="user">
        <br><br>
        Ingrese su contraseña: <br>
        <input type="password" name="pass">
        <br><br>
        <input type="submit" value="Confirmar">
    </form></center>
    <?php
        error_reporting(E_ALL ^ E_NOTICE);
        $clave=$_POST['pass'];
        $nombre=$_POST['user'];
        $conexion=mysqli_connect("localhost","root","","regusuario") or die ("problemas en la conexion");
        mysqli_query($conexion,"insert into usuarios(clave,usuario) values('$clave','$nombre')") or die ("problemas en el select".mysqli_error($conexion));
        mysqli_close($conexion);
        echo"equpo registrado";
    ?>
</body>
</html>