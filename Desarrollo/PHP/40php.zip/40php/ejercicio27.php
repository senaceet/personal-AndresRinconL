<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ejercicio27</title>
</head>
<body>
<center><h2>Diagrama D</h2></center>
    
</body>
</html>