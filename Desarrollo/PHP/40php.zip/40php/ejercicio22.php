<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ejercicio 22</title>
</head>
<body>
    <center><h2>Si en una empresa me dan un subsidio de alimentación de $200.000
mensuales y se trabajan 24 días al mes, donde voy a almorzar diariamente
los almuerzos son a $15.000, cuánto dinero adicional debo colocar yo al mes
para poder cubrir todo el costo del almuerzo durante ese</h2></center>
<?php
$valor1 = 24*15000;
$valor2 = 200000;
$valor3 = $valor1-$valor2;
 echo "<h3>"."El dinero adicional es: ".$valor3."</h3>";

?>

</body>
</html>