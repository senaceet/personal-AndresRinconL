<!DOCTYPE html>
<html lang="ES">
<head>

<meta charset="UTF-8">
<title>Problem 16</title>
<?php
error_reporting(E_ALL ^ E_NOTICE);
date_default_timezone_set('UTC');
echo date('l jS \of F Y h:i:s A')."<br>";
echo date('Y-m-d\TH:i:s');
?>
</head>
</html>