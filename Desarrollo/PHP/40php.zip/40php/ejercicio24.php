<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ejercicio 24</title>
</head>
<body>
    <center><h2>Realizar un programa que permita mostrar en pantalla los números del 1 al
10. Investigar ciclo While</h2></center>
</body>
<?php
$i = 1;
while($i <= 10){

echo $i++."<br>"; 
}


?>
</html>