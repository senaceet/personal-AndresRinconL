<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<center><body>
    <h1>Area de un cuadrado cuyo lado mide 25m</h1><br>
<?php
$lado=25;
$op=$lado*$lado;
echo "El area del cuadrado es: ".$op."^2";
?>
</body></center>
</html>