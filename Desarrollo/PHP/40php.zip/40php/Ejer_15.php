<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<center><body>
    <h1>Peso molecular de Co2 y H2o</h1>
<?php
$C=12;
$o=16;
$h=1;
$op=($C*1)+($o*2);
$op2=($h*2)+($o*1);
echo "El peso de Co2 es: ".$op."g/mol"."<br>";
echo "El peso de H2o es: ".$op2."g/mol";
?>
</body></center>
</html>