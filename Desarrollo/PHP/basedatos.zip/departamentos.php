<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DataBase</title>
</head>
        <body style="background-color:#AAB7B8;"> 
                <center><form action="departamentos.php" method="post">
                                Ingrese codigo:
                                <br>
                                <input type="text" name="codigo">
                                <br>
                                <br>
                                Ingrese departamento:
                                <br>
                                <input type="text" name="departamento">
                                <br>
                                <br>
                                Ingrese capital:
                                <br>
                                <input type="text" name="capital">
                                <br>
                                <br>
                                Ingrese turismo:
                                <br>
                                <input type="text" name="turismo">
                                <br>
                                <br>
                                <input type="submit" value="Enviar">                
                    
                    </form></center>
                    
             <?php
             error_reporting(E_ALL ^ E_NOTICE);
             $codigo=$_POST['codigo'];
             $departamento=$_POST['departamento'];
             $capital=$_POST['capital'];
             $turismo=$_POST['turismo'];
             $conexion=mysqli_connect("localhost","root","","departamentos") or die ("problemas en la conexion");
             mysqli_query($conexion,"insert into capitales(codigo,departamento,capital,turismo) values('$codigo','$departamento','$capital','$turismo')") or die ("problemas en el select".mysqli_error($conexion));
             mysqli_close($conexion);
             echo"Ingresado";   
             ?>

       </body>
</html>
