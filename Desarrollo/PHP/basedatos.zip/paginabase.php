<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Prueba DataBase</title>
</head>
        <body style="background-color:#AAB7B8;"> 
                <center><form action="paginabase.php" method="post">
                                Ingrese codigo:
                                <br>
                                <input type="text" name="codigo">
                                <br>
                                <br>
                                Ingrese nombre:
                                <br>
                                <input type="text" name="nombre">
                                <br>
                                <br>
                                Ingrese correo:
                                <br>
                                <input type="text" name="correo">
                                <br>
                                <br>
                                Ingrese identificacion:
                                <br>
                                <input type="text" name="identificacion">
                                <br>
                                <br>
                                Ingrese fecha:
                                <br>
                                <input type="text" name="fecha">
                                <br>
                                <br>
                                selecciones curso:
                                <br>
                                <select name="curso">
                                    <option value="1">ADSIT1</option>
                                    <option value="2">ADSIT2</option>
                                    <option value="3">ADSIT3</option>
                                    <option value="4">ADSIT4</option>
                                    <option value="5">ADSIT5</option>
                                </select>
                                <br>
                                <br>
                                <input type="submit" value="Enviar">                
                    
                    </form></center>
                    
             <?php
             error_reporting(E_ALL ^ E_NOTICE);
             $sql = "SELECT * FROM `alumnos`";
             $id=$_POST['codigo'];
             $nombre=$_POST['nombre'];
             $correo=$_POST['correo'];
             $identificacion=$_POST['identificacion'];
             $fecha=$_POST['fecha'];
             $conexion=mysqli_connect("localhost","root","","baseprueba") or die ("problemas en la conexion");
             mysqli_query($conexion,"insert into alumnos(id,nombres,correo,identificacion,fecha) values('$id','$nombre','$correo','$identificacion','$fecha')") or die ("problemas en el select".mysqli_error($conexion));
             mysqli_close($conexion);
             echo"El alumno fue ingresado a la base";    
             ?>

       </body>
</html>
