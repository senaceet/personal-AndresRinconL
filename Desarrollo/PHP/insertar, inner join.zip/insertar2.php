<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    
    <?php
    $conexion= mysqli_connect("localhost","root","","baseprueba") or 
    die("Problemas en la conexión");
    mysqli_query($conexion,"insert into alumnos (nombres,correo,codigo) values ('$_REQUEST[correo]','$_REQUEST[codigo]')") or 
    die("problemas en el select".mysqli_error($conexion));
    mysqli_close($conexion);
    echo"Alumno ingresado";
    ?>
</body>
</html>