<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inner Join</title>
</head>
<body>
    <center><form action="innerj,php" method="post">
        Ingrese el codigo del alumno:
        <br><br>
        <input type="text" name="codigo">
        <br><br>
        <input type="submit" value="Enviar">
    </form></center>
    <?php
        error_reporting(E_ALL ^ E_NOTICE);
        $conexion=mysqli_connect("localhost","root","","baseprueba") 
        or die ("problemas en la conexion");
        $registros=mysqli_query($conexion,"select nombres,correo,nombrecurso from alumnos as alumnos inner join codigo as cur on cur.codigo=alu.id
        where alu.id=$_REQUEST[id]")or die("problemas en el select".mysqli_error($conexion));
        if ($reg= mysqli_fetch_array($registros)) {
            echo"Codigo del curso".$reg['codigo']."<br>";
            echo"Nombre del alumno".$reg['nombres']."<br>";
            echo"Correo del alumno".$reg['correo']."<br>";
            echo"curso".$reg['nombrecurso']."<br>";
        } else {
            echo"No existe el alumno";
        }
        mysqli_close($conexion);
    ?>
    
</body>
</html>
