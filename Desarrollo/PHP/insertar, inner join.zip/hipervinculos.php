<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <center>
    <a href="hipervinculos.php? tabla=1">tabla del 1</a> <br>
    <a href="hipervinculos.php? tabla=2">tabla del 2</a> <br>
    <a href="hipervinculos.php? tabla=3">tabla del 3</a> <br>
    <a href="hipervinculos.php? tabla=4">tabla del 4</a> <br>
    <a href="hipervinculos.php? tabla=5">tabla del 5</a> <br>
    <a href="hipervinculos.php? tabla=6">tabla del 6</a> <br>
    <a href="hipervinculos.php? tabla=7">tabla del 7</a> <br>
    <a href="hipervinculos.php? tabla=8">tabla del 8</a> <br>
    <a href="hipervinculos.php? tabla=9">tabla del 9</a> <br>
    <a href="hipervinculos.php? tabla=10">tabla del 10</a> <br>
    </center>
    
    <?php
        error_reporting(E_ALL ^ E_NOTICE);
        echo"Listado de la tabla del ".$_GET['tabla']."<br>";
            for ($i=1; $i <= 10 ; $i++) { 
                $valor=$i*$_GET['tabla'];
                echo$valor.". ";
            }
    ?>
</body>
</html>