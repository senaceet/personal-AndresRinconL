<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contador de registros en una tabla</title>
</head>
<body>
    <form action="insertar2.php" method="post">
        Ingrese el nombre:
        <br>
        <input type="text" name="nombres">
        <br> <br>
        Ingrese el nuevo correo:
        <br>
        <input type="text" name="correo">
        <br> <br>
        codigo curso: 
        <select name="codigo">
        <option value="10">1010</option>
        <option value="20">2020</option>
        <option value="30">3030</option>
        <option value="40">4040</option>
        </select>
    
        <?php
            error_reporting(E_ALL ^ E_NOTICE);
            $conexion= mysqli_connect("localhost","root","","baseprueba") or 
            die("Problemas en la conexión");
            $registros= mysqli_query($conexion,"select codigo,nombrecurso from codigo") or 
            die("problemas en el select".mysqli_error($conexion));
            while ($reg=mysqli_fetch_array($registros)) {
                echo"<option value=\"$reg[codigo]\">$reg[nombrecurso]</option>";
            }            
        ?>
        <br><br>
        <input type="submit" value="enviar">
    </form>
</body>
</html>