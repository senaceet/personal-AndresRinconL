<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>SUMA</h1>
<?php
$numero1 = 2;
$numero2 = 6;
$numero3 = 9;
$resultado = $numero1+$numero2+$numero3;
echo "la suma de " .$numero1.", " .$numero2 .", ",$numero3."<br>"." es: ".$resultado;
?>
</body>
</html>