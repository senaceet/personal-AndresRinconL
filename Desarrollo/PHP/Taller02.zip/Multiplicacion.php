<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>MULTIPLICACION</h1>
<?php
$numero2 = 6;
$numero3 = 9;
$resultado = $numero2*$numero3;
echo "la multiplicacion de " .$numero2 .", ",$numero3."<br>"." es: ".$resultado;
?>
</body>
</html>